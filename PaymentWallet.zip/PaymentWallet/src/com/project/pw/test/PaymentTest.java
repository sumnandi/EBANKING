package com.project.pw.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.project.pw.bean.PaymentBean;
import com.project.pw.dao.PaymentDao;
import com.project.pw.service.PaymentService;

import junit.framework.Assert;

public class PaymentTest {

	@Test
	public void testValidatePhoneNo() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(true, check.validateCustPhoneNumber("9247445343"));
		
	}
	
	@Test
	public void testValidateName() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(true, check.validateCustName("Madhavi Vullengula"));
		
	}
	
	@Test
	public void testValidatePwd() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(true, check.validateCustPwd("Abcd123@"));
		
	}

	@Test
	public void testValidateAge()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(true, check.validateCustAge(21));
	}
	
	@Test
	public void testValidateAmt()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(true, check.validateAmt(50000.00));
	}
	@Test
	public void testValidatePhoneNoFail() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(false, check.validateCustPhoneNumber("76533576865432"));
		
	}
	
	@Test
	public void testValidateNameFail() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(false, check.validateCustName("Madzz3@"));
		
	}
	
	@Test
	public void testValidatePwdFail() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(false, check.validateCustPwd("*&^ hey!"));
		
	}

	@Test
	public void testValidateAgeFail()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(false, check.validateCustAge(152));
	}
	
	@Test
	public void testValidateAmtFail()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(false, check.validateAmt(0.00));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testAccCreation()
	{
		PaymentDao w = new PaymentDao();
		PaymentBean a = new PaymentBean();
		Assert.assertEquals(10100,w.accountCreation(a));
		PaymentBean a1 = new PaymentBean();
		Assert.assertEquals(10101,w.accountCreation(a1));
		PaymentBean a2 = new PaymentBean();
		Assert.assertEquals(10102,w.accountCreation(a2));
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testDepositAmt()
	{
		PaymentService w = new PaymentService();
		PaymentBean a = new PaymentBean();
		Assert.assertEquals(8000.00, w.deposit(8000.00));
		Assert.assertEquals(4543.00, w.deposit(4543.00));
		
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testWithdrawAmt() throws Exception
	{
		PaymentService w = new PaymentService();
		PaymentBean a = new PaymentBean();
		
		Assert.assertEquals(8000.00, w.deposit(8000.00));
		Assert.assertEquals(1000.00, w.withdraw(1000.00));
		Assert.assertEquals(00.00, w.withdraw(2000.00));
		
	}
	
	@Test
	public void testDispBal()
	{
		PaymentService w = new PaymentService();
		PaymentBean a = new PaymentBean();
		Assert.assertEquals(0.00,w.showBalance());
		
		
	}
	
	@Test
	public void testLogin()
	{
		PaymentDao w = new PaymentDao();
		PaymentBean a = new PaymentBean();
		w.accountCreation(a);
		PaymentBean a1 = new PaymentBean();
		w.accountCreation(a1);
		PaymentBean a2 = new PaymentBean();
		w.accountCreation(a2);
		PaymentBean a3 = new PaymentBean();
		w.accountCreation(a3);
		System.out.println(a3.getAccNum());
		Assert.assertEquals(a1, w.loginUser(10104));
	}
}
