package com.project.pw.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

import com.project.pw.bean.PaymentBean;

public class PaymentDao implements IPaymentDao {

	TreeMap<Integer, PaymentBean> tmap = new TreeMap<Integer, PaymentBean>();
	
	
	
	//Account Creation
	@Override
	public int accountCreation(PaymentBean a) {
		a.setAccNum();
		tmap.put(a.getAccNum(), a);
		return a.getAccNum();
	}

	@Override
	public PaymentBean loginUser(int accNo) {
		
		return tmap.get(accNo);		
	}

	
	//Updating the details
	@Override
	public void updateDetails(int accNo, PaymentBean a) {
		tmap.replace(accNo, a);
		
	}

}
